import Combine
import Foundation
import Security
import UIKit

// ============================================================
// v21.0 · 真卡密门禁
// - 卡密由后台（ek.x8iu.com）签发，到期时间以服务端为准
// - 第一次验证后写进本机钥匙串，之后启动不再输入
// - 卡密到期 / 被后台禁用 → 立即锁回验证页
// - 断网时给 72 小时离线宽限，超时就必须联网校验
// ============================================================

@MainActor
final class LicenseManager: ObservableObject {

    enum Gate: Equatable {
        case checking          // 正在校验
        case locked            // 没卡密 / 没通过
        case unlocked          // 已激活且未到期
        case expired           // 卡密已到期
    }

    @Published private(set) var state: Gate = .checking
    @Published private(set) var expiration: Date?
    @Published private(set) var isBusy = false
    @Published private(set) var message: String?
    @Published private(set) var lastError: String?

    /// 校验接口（后台 api/verify.php）
    static let verifyEndpoint = "https://ek.x8iu.com/api/verify.php"
    /// 断网宽限
    static let offlineGrace: TimeInterval = 72 * 3600
    /// 本地时钟被往回拨的容忍秒数
    static let clockTolerance: TimeInterval = 600

    /// 永久卡在本地记成这个日期（2100-01-01），界面上不显示到期
    static let permanentDate = Date(timeIntervalSince1970: 4_102_444_800)

    private let service = "com.langshen.license.v21"
    private let kCode = "code"
    private let kExp = "exp"
    private let kCheck = "lastcheck"

    var isUnlocked: Bool { state == .unlocked }
    var savedCode: String { string(for: kCode) ?? "" }

    /// v28.0 · 本机到底有没有卡密（进过界面缓存，别在 View body 里反复读钥匙串）
    @Published private(set) var hasSavedCode: Bool = false

    /// 还剩几天（永久卡 / 没有到期日 = nil）
    var remainingDays: Int? {
        guard let expiration else { return nil }
        if expiration >= Self.permanentDate { return nil }
        let cal = Calendar.current
        let from = cal.startOfDay(for: Date())
        let to = cal.startOfDay(for: expiration)
        return cal.dateComponents([.day], from: from, to: to).day
    }

    /// 永久卡（本地记的是 2100-01-01）
    var isPermanent: Bool {
        guard let expiration else { return false }
        return expiration >= Self.permanentDate
    }

    /// 界面上显示的到期文案：永久卡直接写「永久有效」
    var expiryLabel: String {
        guard expiration != nil else { return "待验证" }
        return isPermanent ? "永久有效" : expirationText
    }

    var expirationText: String {
        guard let expiration else { return "" }
        let f = DateFormatter()
        f.locale = Locale(identifier: "zh_CN")
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: expiration)
    }

    // MARK: - 启动（v27.0 重写）

    // 规则只有一条：卡密验过一次、本地没到期，就永远不再弹出来。
    // 网络好不好、离线多久、回多少次前台，都不影响；只有「本地到期了」才重新要卡密。

    private var refreshing = false
    private var lastLaunchCheck = Date.distantPast

    /// 只读本机钥匙串，不联网，毫秒级出结论。启动第一帧就靠它。
    func bootstrapLocal() {
        let code = savedCode
        hasSavedCode = !code.isEmpty
        guard !code.isEmpty else {
            state = .locked
            expiration = nil
            message = nil
            return
        }
        guard let exp = date(for: kExp) else {
            // 老数据：有卡密但没记到到期日 → 先放行，后台再核，核不到也不打扰
            state = .unlocked
            expiration = nil
            message = nil
            return
        }
        if exp >= Self.permanentDate {
            expiration = nil
            state = .unlocked
            message = nil
            return
        }
        expiration = exp
        if exp <= Date() {
            state = .expired
            message = "卡密已于 \(expirationText) 到期"
        } else {
            state = .unlocked
            message = nil
        }
    }

    /// 冷启动 / 回到前台：先本地出结论，再在后台悄悄刷一次。
    /// 已经放行的状态绝不被网络问题改回去。
    func refreshOnLaunch() async {
        bootstrapLocal()

        let code = savedCode
        guard !code.isEmpty else { return }

        if isUnlocked {
            // 已放行：后台静默核一次（续期用），失败什么都不改
            guard Date().timeIntervalSince(lastLaunchCheck) > 60 else { return }
            lastLaunchCheck = Date()
            _ = await verify(code: code, silent: true)
            state = .unlocked          // 本地没到期 → 永远保持放行
            return
        }

        // 只有「本地没卡密 / 本地已到期」才联网核一次（可能后台刚续期）
        guard !refreshing else { return }
        refreshing = true
        defer { refreshing = false }

        isBusy = true
        defer { isBusy = false }

        let ok = await verify(code: code, silent: true)
        if ok {
            state = .unlocked
            message = nil
        } else if state != .unlocked {
            let exp = expiration ?? date(for: kExp)
            if let exp, exp > Date() {
                // 本地还没到期，网络失败不算数 → 继续放行
                state = .unlocked
            } else {
                state = .expired
                message = lastError ?? "卡密已到期，请续费后重试"
            }
        }
    }

    // MARK: - 激活

    func activate(code rawCode: String) async {
        let code = rawCode.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !code.isEmpty, !isBusy else { return }
        isBusy = true
        message = nil
        defer { isBusy = false }

        let ok = await verify(code: code, silent: false)
        if ok {
            save(code, for: kCode)
            saveTimestamp(Date(), for: kCheck)
            hasSavedCode = true
            state = .unlocked
            message = nil
        } else {
            state = .locked
            message = lastError ?? "卡密不正确"
        }
    }

    /// 续费：输入一张新卡密，把它带的时长加到当前这张上
    func renew(code rawCode: String) async -> (ok: Bool, msg: String) {
        let code = rawCode.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !code.isEmpty else { return (false, "先把续费卡密填进来") }
        guard !isBusy else { return (false, "正在验证，等这一下跑完再试") }

        let current = savedCode
        if current.isEmpty {
            // 还没绑过卡密，就当正常激活
            await activate(code: code)
            return (isUnlocked, isUnlocked ? "这张卡密已经开通" : (message ?? "卡密不正确"))
        }
        if current.uppercased() == code {
            return (false, "这就是现在用的这张卡，换一张续费卡再试")
        }

        isBusy = true
        defer { isBusy = false }

        let ok = await verify(code: code, silent: false, mode: "renew", base: current)
        if ok {
            saveTimestamp(Date(), for: kCheck)
            state = .unlocked
            message = nil
            return (true, "续费成功，到期时间已经往后延")
        }
        return (false, lastError ?? "续费失败，这张卡密不可用")
    }

    func deactivate() {
        delete(kCode); delete(kExp); delete(kCheck)
        hasSavedCode = false
        state = .locked
        expiration = nil
        message = nil
    }

    // MARK: - 网络校验

    /// 返回 true = 卡密有效且未到期
    private func verify(code: String, silent: Bool, mode: String = "", base: String = "") async -> Bool {
        lastError = nil

        var req = URLRequest(url: URL(string: Self.verifyEndpoint)!)
        req.httpMethod = "POST"
        req.timeoutInterval = 15
        req.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.setValue("浪神/23.0", forHTTPHeaderField: "User-Agent")

        let device = UIDevice.current.identifierForVendor?.uuidString ?? "unknown"
        var body = [
            "code": code,
            "device": device,
            "ver": "23.0",
            "t": String(Int(Date().timeIntervalSince1970))
        ]
        if !mode.isEmpty { body["mode"] = mode }
        if !base.isEmpty { body["base"] = base }
        let encoded = body
        .map { "\($0.key)=\(Self.escape($0.value))" }
        .joined(separator: "&")
        req.httpBody = Data(encoded.utf8)

        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            guard let http = resp as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                lastError = "验证服务器返回异常，请稍后再试"
                return false
            }
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                lastError = "验证服务器返回内容看不懂，请联系管理员"
                return false
            }

            let ok = (json["ok"] as? Bool) ?? ((json["ok"] as? Int) == 1)
            if ok {
                let expValue: Double = {
                    if let n = json["exp"] as? NSNumber { return n.doubleValue }
                    if let s = json["exp"] as? String, let d = Double(s) { return d }
                    return 0
                }()
                if expValue > 0 {
                    let date = Date(timeIntervalSince1970: expValue)
                    if date <= Date() {
                        saveTimestamp(date, for: kExp)
                        saveTimestamp(Date(), for: kCheck)
                        expiration = date
                        lastError = "卡密已于 \(expirationText) 到期"
                        return false
                    }
                    saveTimestamp(date, for: kExp)
                    expiration = date
                } else {
                    // 后台发的是「永久」：本地记一个很远的日期，界面上不显示到期
                    saveTimestamp(Self.permanentDate, for: kExp)
                    expiration = nil
                }
                saveTimestamp(Date(), for: kCheck)
                return true
            }

            let msg = (json["msg"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
            lastError = (msg?.isEmpty == false) ? msg : "卡密不正确或已失效"
            return false
        } catch {
            lastError = "连不上验证服务器，请检查网络后再试"
            return false
        }
    }

    private static func escape(_ value: String) -> String {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        return value.addingPercentEncoding(withAllowedCharacters: allowed) ?? value
    }

    // MARK: - 卡密存储（v29.0：四处兜底，先写一定写得进去的地方）
    //
    // 踩过的坑，一条一条列清楚，别再犯：
    // 1) 只放钥匙串 → 全能签 / Sideloadly 重签后没有钥匙串访问组权限，
    //    SecItemAdd 直接返回 -34018，一个字都存不进去 → 每次启动都当没卡密 → 每次弹输入框。
    // 2) 防封自检整类清钥匙串 → 把自己的卡密一起清了 → 进首页又弹卡密页。
    // 3) 只写一个文件 → 被清缓存 / 被系统清 Documents，又白输一次。
    //
    // 现在写的时候先写「文件 + 偏好」（不需要任何权限，重签也一定写得进），
    // 最后才写钥匙串（写得进就写，写不进也不影响记住登录）。
    // 读的时候四处都看，哪一处有就用，并顺手把其它几处补回去。

    private static let fallbackPrefix = "ls.license.fb."
    private static let fallbackName = "license.dat"

    private static func prefDirectories() -> [URL] {
        let fm = FileManager.default
        var list: [URL] = []
        if let docs = fm.urls(for: .documentDirectory, in: .userDomainMask).first {
            list.append(docs.appendingPathComponent("LSPrefs", isDirectory: true))
        }
        if let support = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first {
            list.append(support.appendingPathComponent("LSPrefs", isDirectory: true))
        }
        if list.isEmpty {
            list.append(
                URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
                    .appendingPathComponent("LSPrefs", isDirectory: true)
            )
        }
        return list
    }

    private static var fallbackFileURLs: [URL] {
        prefDirectories().map { $0.appendingPathComponent(fallbackName) }
    }

    private func fallbackMap() -> [String: String] {
        var map: [String: String] = [:]
        // 1) 先读文件（最耐操：重签、清钥匙串、清缓存都不动它）
        for url in Self.fallbackFileURLs {
            guard let stored = try? Data(contentsOf: url) else { continue }
            let raw = Data(base64Encoded: stored) ?? stored
            guard let parsed = try? JSONSerialization.jsonObject(with: raw, options: []),
                  let obj = parsed as? [String: String] else { continue }
            for (k, v) in obj where !v.isEmpty { map[k] = v }
        }
        // 2) 缺的再用偏好补
        for key in [kCode, kExp, kCheck] where map[key] == nil {
            if let v = UserDefaults.standard.string(forKey: Self.fallbackPrefix + key), !v.isEmpty {
                map[key] = v
            }
        }
        return map
    }

    private func setFallback(_ value: String?, for account: String) {
        var map = fallbackMap()
        if let value = value, !value.isEmpty {
            map[account] = value
        } else {
            map.removeValue(forKey: account)
        }

        if let data = try? JSONSerialization.data(withJSONObject: map, options: []) {
            let payload = data.base64EncodedData()
            for url in Self.fallbackFileURLs {
                do {
                    try FileManager.default.createDirectory(
                        at: url.deletingLastPathComponent(),
                        withIntermediateDirectories: true
                    )
                    try payload.write(to: url, options: .atomic)
                } catch {
                    // 某一处写不进去不影响别的：只要还有一处留着就照样免输
                }
            }
        }

        for key in [kCode, kExp, kCheck] {
            if let v = map[key], !v.isEmpty {
                UserDefaults.standard.set(v, forKey: Self.fallbackPrefix + key)
            } else {
                UserDefaults.standard.removeObject(forKey: Self.fallbackPrefix + key)
            }
        }
    }

    // MARK: - 钥匙串

    private func keychainString(for account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func saveKeychain(_ value: String, for account: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        var item = base
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    /// 读：钥匙串 → 本地兜底（文件 / 偏好），哪一处有就用，并顺手把缺的那几处补回去
    private func string(for account: String) -> String? {
        if let v = keychainString(for: account), !v.isEmpty {
            // 钥匙串里有、文件里没有：补一份文件，下次被清钥匙串也还在
            if fallbackMap()[account] == nil { setFallback(v, for: account) }
            return v
        }
        if let v = fallbackMap()[account], !v.isEmpty {
            saveKeychain(v, for: account)
            return v
        }
        return nil
    }

    /// 写：先写文件和偏好（不需要任何权限，重签也一定写得进），最后才写钥匙串
    private func save(_ value: String, for account: String) {
        setFallback(value, for: account)
        saveKeychain(value, for: account)
    }

    private func saveTimestamp(_ date: Date, for account: String) {
        save(String(Int(date.timeIntervalSince1970)), for: account)
    }

    private func date(for account: String) -> Date? {
        guard let raw = string(for: account), let secs = TimeInterval(raw) else { return nil }
        return Date(timeIntervalSince1970: secs)
    }

    private func delete(_ account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
        setFallback(nil, for: account)
    }
}
