import Foundation
import SwiftUI
import UIKit
import Combine

// ============================================================
// v25.0 · 卡密窗口在线换装
// ------------------------------------------------------------
// 后台（ek.x8iu.com/index.php →「卡密窗口」）改文案 / 配色 / 背景图，
// 保存后写 api/license-theme.json，App 每次进卡密页拉一次：
//   · version 变了就整套换掉
//   · 背景图 / 标志图下载到本机 Caches，断网用上次那张
//   · 服务端没配、拉不到、内容坏了 → 一律回落到内置默认（就是现在这套）
// 不会因为后台挂了就把用户挡在门外。
// ============================================================

struct LicenseTheme: Codable, Equatable {
    /// 每次后台保存 +1，App 靠它判断要不要换
    var version: Int = 0

    // 文案
    var title: String = "浪神"
    var subtitle: String = "清残留 防封号 玩得稳"
    var section: String = "授权验证"
    var fieldLabel: String = "请输入浪神卡密"
    var placeholder: String = "请输入您的授权码"
    var button: String = "立即验证"
    var footer: String = "卡密可在官方渠道获取"
    var copyright: String = "浪神 2026 版权 @浪神所有"

    // 配色（#RRGGBB）
    var primary: String = "#29EB85"
    var secondary: String = "#12A38F"
    var accent: String = "#8F70F5"
    var inputText: String = "#1A1A1A"

    // 版式
    var dim: Double = 0.62          // 压暗强度 0.15 – 0.95
    var corner: Double = 28         // 输入框 / 按钮圆角
    var showShield: Bool = true     // 顶部盾牌
    var buttonGradient: Bool = true // 按钮渐变（关掉=纯主色）

    // 图片（存相对路径或全 URL，空 = 用启动视频定格）
    var background: String = ""
    var logo: String = ""

    enum CodingKeys: String, CodingKey {
        case version, title, subtitle, section, fieldLabel, placeholder, button, footer, copyright
        case primary, secondary, accent, inputText, dim, corner, showShield, buttonGradient
        case background, logo
    }

    init() {}

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let d = LicenseTheme()
        func str(_ k: CodingKeys, _ fb: String) -> String {
            let v = try? c.decode(String.self, forKey: k)
            return (v?.isEmpty == false) ? v! : fb
        }
        version         = (try? c.decode(Int.self, forKey: .version)) ?? d.version
        title           = str(.title, d.title)
        subtitle        = str(.subtitle, d.subtitle)
        section         = str(.section, d.section)
        fieldLabel      = str(.fieldLabel, d.fieldLabel)
        placeholder     = str(.placeholder, d.placeholder)
        button          = str(.button, d.button)
        footer          = str(.footer, d.footer)
        copyright       = str(.copyright, d.copyright)
        primary         = str(.primary, d.primary)
        secondary       = str(.secondary, d.secondary)
        accent          = str(.accent, d.accent)
        inputText       = str(.inputText, d.inputText)
        dim             = (try? c.decode(Double.self, forKey: .dim)) ?? d.dim
        corner          = (try? c.decode(Double.self, forKey: .corner)) ?? d.corner
        showShield      = (try? c.decode(Bool.self, forKey: .showShield)) ?? d.showShield
        buttonGradient  = (try? c.decode(Bool.self, forKey: .buttonGradient)) ?? d.buttonGradient
        background      = (try? c.decode(String.self, forKey: .background)) ?? ""
        logo            = (try? c.decode(String.self, forKey: .logo)) ?? ""
        // 兜底：颜色格式不对就用默认，别让整页变透明
        if LSThemeColor.rgb(primary) == nil { primary = d.primary }
        if LSThemeColor.rgb(secondary) == nil { secondary = d.secondary }
        if LSThemeColor.rgb(accent) == nil { accent = d.accent }
        if LSThemeColor.rgb(inputText) == nil { inputText = d.inputText }
        dim = min(0.95, max(0.15, dim))
        corner = min(40, max(8, corner))
    }
}

/// #RRGGBB / #RGB → RGB(0–1)
enum LSThemeColor {
    static func rgb(_ hex: String) -> (Double, Double, Double)? {
        var s = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if s.hasPrefix("#") { s.removeFirst() }
        if s.count == 3 {
            s = s.map { "\($0)\($0)" }.joined()
        }
        guard s.count == 6, let v = UInt32(s, radix: 16) else { return nil }
        return (Double((v >> 16) & 0xFF) / 255.0,
                Double((v >> 8) & 0xFF) / 255.0,
                Double(v & 0xFF) / 255.0)
    }

    static func color(_ hex: String, fallback: Color) -> Color {
        guard let c = rgb(hex) else { return fallback }
        return Color(red: c.0, green: c.1, blue: c.2)
    }
}

/// 不给这个类打 @MainActor：SwiftUI 里 @StateObject 的默认值在非隔离上下文求值，
/// 打了标注反而会在某些 Xcode 版本上报 "main actor-isolated initializer" 的错。
/// 所有 @Published 赋值都显式回到主线程。
final class LicenseThemeStore: ObservableObject {
    static let shared = LicenseThemeStore()

    /// 跟验证接口同域，后台放在站点根目录就自动生成这个文件
    static let endpoint = "https://ek.x8iu.com/api/license-theme.json"
    static let siteBase = "https://ek.x8iu.com"

    @Published private(set) var theme: LicenseTheme = LicenseTheme()
    @Published private(set) var backgroundImage: UIImage?
    @Published private(set) var logoImage: UIImage?

    private let kTheme = "ls.theme.json"
    private let kBg = "ls.theme.bg"
    private let kLogo = "ls.theme.logo"
    private var refreshing = false

    private init() {
        loadCache()
    }

    // MARK: - 本机缓存

    private func loadCache() {
        if let data = UserDefaults.standard.data(forKey: kTheme),
           let cached = try? JSONDecoder().decode(LicenseTheme.self, from: data) {
            theme = cached
        }
        if let path = UserDefaults.standard.string(forKey: kBg) {
            backgroundImage = UIImage(contentsOfFile: path)
        }
        if let path = UserDefaults.standard.string(forKey: kLogo) {
            logoImage = UIImage(contentsOfFile: path)
        }
    }

    private func cacheDir() -> URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("LSTheme", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    // MARK: - 拉最新

    /// 进卡密页时调一次；失败就继续用缓存，不弹任何错
    func refresh() async {
        guard !refreshing else { return }
        refreshing = true
        defer { refreshing = false }

        guard let url = URL(string: Self.endpoint) else { return }
        var req = URLRequest(url: url)
        req.timeoutInterval = 8
        req.cachePolicy = .reloadIgnoringLocalCacheData
        req.setValue("no-cache", forHTTPHeaderField: "Cache-Control")

        guard let (data, resp) = try? await URLSession.shared.data(for: req),
              let http = resp as? HTTPURLResponse,
              (200...299).contains(http.statusCode),
              !data.isEmpty else { return }

        guard let incoming = Self.decode(data) else { return }

        // 同一版就不重复写盘 / 重复下图片
        let current = await MainActor.run { self.theme }
        if incoming == current {
            await syncImages(theme: incoming, force: false)
            return
        }

        await MainActor.run { self.theme = incoming }
        if let encoded = try? JSONEncoder().encode(incoming) {
            UserDefaults.standard.set(encoded, forKey: kTheme)
        }
        await syncImages(theme: incoming, force: true)
    }

    /// 兼容两种返回：{"ok":true,"theme":{...}} 或 {"version":...}
    private static func decode(_ data: Data) -> LicenseTheme? {
        struct Envelope: Codable { var theme: LicenseTheme? }
        if let env = try? JSONDecoder().decode(Envelope.self, from: data), let t = env.theme {
            return t
        }
        return try? JSONDecoder().decode(LicenseTheme.self, from: data)
    }

    private func absolute(_ path: String) -> URL? {
        let p = path.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !p.isEmpty else { return nil }
        if p.lowercased().hasPrefix("http") { return URL(string: p) }
        let base = Self.siteBase
        let tail = p.hasPrefix("/") ? p : "/" + p
        return URL(string: base + tail)
    }

    private func syncImages(theme t: LicenseTheme, force: Bool) async {
        let dir = cacheDir()

        var newBG: UIImage?
        var clearBG = false

        if let url = absolute(t.background) {
            let file = dir.appendingPathComponent("bg-\(t.version).jpg")
            if force || !FileManager.default.fileExists(atPath: file.path) {
                if let (img, _) = try? await fetchImage(url), let data = img.jpegData(compressionQuality: 0.92) {
                    try? data.write(to: file)
                    UserDefaults.standard.set(file.path, forKey: kBg)
                    newBG = img
                }
            } else if backgroundImage == nil {
                newBG = UIImage(contentsOfFile: file.path)
            }
        } else if t.background.isEmpty {
            // 后台把背景图清了 → 回到「启动视频定格」那一版
            clearBG = true
            UserDefaults.standard.removeObject(forKey: kBg)
        }
        // 配了但下载失败：保留缓存那张，别清空

        var newLogo: UIImage?
        var clearLogo = false

        if let url = absolute(t.logo) {
            let file = dir.appendingPathComponent("logo-\(t.version).png")
            if force || !FileManager.default.fileExists(atPath: file.path) {
                if let (img, _) = try? await fetchImage(url) {
                    try? img.pngData()?.write(to: file)
                    UserDefaults.standard.set(file.path, forKey: kLogo)
                    newLogo = img
                }
            } else if logoImage == nil {
                newLogo = UIImage(contentsOfFile: file.path)
            }
        } else {
            clearLogo = true
            UserDefaults.standard.removeObject(forKey: kLogo)
        }

        await MainActor.run {
            if clearBG { self.backgroundImage = nil }
            if let newBG { self.backgroundImage = newBG }
            if clearLogo { self.logoImage = nil }
            if let newLogo { self.logoImage = newLogo }
        }
    }

    private func fetchImage(_ url: URL) async throws -> (UIImage, Data) {
        var req = URLRequest(url: url)
        req.timeoutInterval = 12
        req.cachePolicy = .reloadIgnoringLocalCacheData
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse, (200...299).contains(http.statusCode),
              let img = UIImage(data: data) else {
            throw URLError(.cannotDecodeContentData)
        }
        return (img, data)
    }
}
